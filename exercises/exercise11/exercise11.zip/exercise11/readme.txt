1- import fontawesome library for phone icon
2- import shabnam font